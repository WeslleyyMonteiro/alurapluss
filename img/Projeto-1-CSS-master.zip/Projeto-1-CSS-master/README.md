<h3>Primeiro projeto usando CSS, com a finalidade de treinar tudo o que aprendi no modulo 1 de css do DevClub.</h3>
<br>
<p>Tecnologias uzadas:</p>
<p>-HTML</p>
<p>-CSS</p>
<br>
<br>
<img width="900" src="img/foto5.png" />
